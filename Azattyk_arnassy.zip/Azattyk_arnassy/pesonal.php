<?php
$cookie_name = "loggenIn";
if(isset($_COOKIE[$cookie_name])){
    $cookie_value = $_COOKIE[$cookie_name];
    echo "Салем $cookie_value !";
    echo '<a href= "logout.php">Logout</a>';
}
?>