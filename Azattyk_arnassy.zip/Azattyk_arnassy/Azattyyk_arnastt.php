<?php
function OpenConn(){
  $servername = "localhost";
  $username="root";
  $password="";
  $dbname="azattyk_news";
  $conn=mysqli_connect($servername,$username,$password,$dbname);
  if(mysqli_connect_errno()){
    die("Connection failed: " . $conn->connect_error);
    return null;
  }else{
      return $conn;
  }
  }
  function CloseConn($conn){
      mysqli_close($conn);
  }
$conn=OpenConn();

?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>
    <title>Azattyk arnasy</title>
    <link rel="stylesheet" href="Новая папка/style.css">
    <link rel="stylesheet" href="Новая папка/script.js">

</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="#home"><p class="display-6" style="font-family: Arial,bold ;"><img src="Новая папка/logo.jpg" alt="logo" width="80" height="80">  Азаттық арнасы</p></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
      
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
          <ul class="navbar-nav mr-auto">
            <li class="nav-item active">
              <a class="nav-link" href="#home"><p class="ffff" style="font-size: 28px ;"> Басты бет <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> </p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Kogam.html"> <p class="ffff" style="font-size: 28px ;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> Қоғам <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg></p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Sport.html"> <p class="ffff" style="font-size: 28px ;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> Спорт <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg></p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"> <p class="ffff" style="font-size: 28px ;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> Экономика <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg></p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#"> <p class="ffff" style="font-size: 28px ;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> Әлемдік <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg></p></a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="#footer"> <p class="ffff" style="font-size: 28px ;"><svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg> Байланыс <svg xmlns="http://www.w3.org/2000/svg" width="25" height="50" fill="currentColor" class="bi bi-grip-vertical" viewBox="0 0 16 16">
                <path d="M7 2a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 5a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zM7 8a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm-3 3a1 1 0 1 1-2 0 1 1 0 0 1 2 0zm3 0a1 1 0 1 1-2 0 1 1 0 0 1 2 0z"/>
              </svg></p></a>
            </li>
          </ul>
        </div>

      </nav>
      <div class="container"> 
      <section id="home"><br>
        <h1 class="neonText" align="center">Өзекті жаңалықтар</h1>
        <br>
        <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel" style="height: 600px ; width: 700px; margin-left: 250px;">
          
          <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
          </div>
          <div class="carousel-inner" >
            <div class="carousel-item active" data-bs-interval="10000">
              <img src="Новая папка/carousel.png" class="d-block w-100" alt="carousel">
              <h5 align="center">Қазақстанда жаңа саяси партия тіркелді</h5>
                <p>Астана. 30 қараша. Азаттық – Қазақстанда «Байтақ» жаңа саяси партиясы тіркелді, деп хабарлайды агенттік тілшісі.</p>
            </div>
            <div class="carousel-item" data-bs-interval="2000">
              <img src="Новая папка/carousel1.jpg" class="d-block w-100" alt="carousel">
              <h5>Қазақстанда автобуспен жүруден басқа барлық қызмет түрлері қымбаттады</h5>
              <p>BNS ASPIR RK деректері бойынша ағымдағы жылдың қаңтар және қазан айларындағы кейбір қызметтердің елдегі орташа бағасына талдау жүргізілді, деп хабарлайды NewTimes.kz.</p>
            </div>
            <div class="carousel-item">
              <img src="Новая папка/carousel2.jpg" class="d-block w-100" alt="carousel">
                <h5>Қазақстан мен Швейцария қымбат металдарды таңбалау бойынша ынтымақтасады</h5>
                <p>Мәжілісте «Қазақстан Республикасының Үкіметі мен Швейцария Конфедерациясының Федералдық Кеңесі арасындағы бағалы металдан жасалған бұйымдарға таңбаны өзара тану туралы келісімді ратификациялау туралы» Қазақстан Республикасы Заңының жобасы қаралады, деп хабарлайды Azattyk.kz.</p>

            </div>
          </div>
          <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark"  data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Предыдущий</span>
          </button>
          <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark"  data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Следующий</span>
          </button>
        </div><br><br>
        <h1 class="neonText" align="center">Соңғы жаңалықтар</h1><br><br>
        <div class="row">
        <div class="col-sm-4">
                           <div class="card">
                               <div class="card-body text-center">
                                   <img class="card-img-top" src="Новая папка/card1.webp" width="100px" height="300px" alt="Card image cap">
                                   <br><br>
                                   <h3 class="card-title" align="center">Рудныйда ондаған тұрғын үй және бір мектеп жылусыз қалды.</h5>
                                   <h6 align="center">Қостанай облысы Рудный қаласында жылу құбырының жарылуы салдарынан 13 жеке үй, 33 көпқабатты үй және бір мектеп жылусыз .....</p>
                                   <br> 
                                    <p>Қоғам жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                    <a href="#" class="btn btn-primary">Толығырақ</a>
                               </div>
                           </div>
                          </div>
                          <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="card-img-top" src="Новая папка/card2.webp" width="100px" height="300px" alt="Card image cap">
                                    <br><br>
                                    <h3 class="card-title" align="center">Қалың қар, боран: қыстың алғашқы күндері елде ауа райы қандай болады.</h5>
                                    <h6 align="center">Синоптиктер қыстың алғашқы күндері ел аумағында ауа температурасы.....</p>
                                    <br> 
                                     <p>Қоғам жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                     <a href="#" class="btn btn-primary">Толығырақ</a>
                                </div>
                            </div>
                           </div>
                           <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="card-img-top" src="Новая папка/card3.webp" width="100px" height="300px" alt="Card image cap">
                                    <br><br>
                                    <h3 class="card-title" align="center">Тоқаев Франциядағы ірі компания басшыларымен кездесті (фото).</h5>
                                    <h6 align="center">Мемлекет басшысы Францияның атом өнеркәсібі, энергетика, өнеркәсіптік газдарды өндіру ....</p>
                                    <br> 
                                     <p>Саясат жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                     <a href="#" class="btn btn-primary">Толығырақ</a>
                                </div>
                            </div>
                           </div>
                           <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="card-img-top" src="Новая папка/ddd.webp" width="100px" height="300px" alt="Card image cap">
                                    <br><br>
                                    <h3 class="card-title" align="center">Тоқаев Эмманюэль Макронды Қазақстанға шақырды (фото).</h5>
                                    <h6 align="center">Парижге ресми сапармен келген мемлекет басшысы Қасым-Жомарт Тоқаев Франция президенті Эмманюэль Макронмен кеңейтілген құрамда келіссөз.....</p>
                                    <br> 
                                     <p>Саясат жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                     <a href="#" class="btn btn-primary">Толығырақ</a>
                                </div>
                            </div>
                           </div>
                           <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="card-img-top" src="Новая папка/card5.webp" width="100px" height="300px" alt="Card image cap">
                                    <br><br>
                                    <h3 class="card-title" align="center">Бірқатар ЖЭО мемлекет меншігіне қайтарылады.</h5>
                                    <h6 align="center">Үкімет пен Бас прокуратура бірқатар ЖЭО-ны мемлекет меншігіне қайтару бойынша алдын ала жұмыс жүргізіп жатыр, деп хабарлайды Azattyk.kz</p>
                                    <br> 
                                     <p>Экономика жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                     <a href="#" class="btn btn-primary">Толығырақ</a>
                                </div>
                            </div>
                           </div>
                           <div class="col-sm-4">
                            <div class="card">
                                <div class="card-body text-center">
                                    <img class="card-img-top" src="Новая папка/card6.webp" width="100px" height="300px" alt="Card image cap">
                                    <br><br>
                                    <h3 class="card-title" align="center">Иран футболдан әлем чемпионатындағы жеңісінің құрметіне 700-ден астам тұтқынды босатпақ.</h5>
                                    <h6 align="center">Иран билігі Катарда өтіп жатқан футболдан әлем чемпионатында ұлттық құраманың Уэльс командасын.......</p>
                                    <br> 
                                     <p>Әлемдік жаңалықтарын толық оқу үшін Толығырақ батырмасын басыңыз  </p>
                                     <a href="#" class="btn btn-primary">Толығырақ</a>
                                </div>
                            </div>
                           </div>           
          </div>
    </div>
    <br><br>
    <section id="footer">
    <h1 class="neonText" align="center">Бізбен байланыс</h1><br>
    <footer class="text-center text-lg-start bg-light text-muted">  
      <section
        class="d-flex justify-content-center justify-content-lg-between p-4 border-bottom"
      >
        <div class="me-5 d-none d-lg-block">
          <h5>Бізге әлеуметтік желілерде хабарласыңыз:</span>
        </div>
        <div>
          <a href="https://web.whatsapp.com/" class="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-whatsapp" viewBox="0 0 16 16">
                  <path d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z"/>
                </svg>
          </a>
          <a href="https://t.me/news_azattyqkz_bot" class="btn btn-primary">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-telegram" viewBox="0 0 16 16">
              <path d="M16 8A8 8 0 1 1 0 8a8 8 0 0 1 16 0zM8.287 5.906c-.778.324-2.334.994-4.666 2.01-.378.15-.577.298-.595.442-.03.243.275.339.69.47l.175.055c.408.133.958.288 1.243.294.26.006.549-.1.868-.32 2.179-1.471 3.304-2.214 3.374-2.23.05-.012.12-.026.166.016.047.041.042.12.037.141-.03.129-1.227 1.241-1.846 1.817-.193.18-.33.307-.358.336a8.154 8.154 0 0 1-.188.186c-.38.366-.664.64.015 1.088.327.216.589.393.85.571.284.194.568.387.936.629.093.06.183.125.27.187.331.236.63.448.997.414.214-.02.435-.22.547-.82.265-1.417.786-4.486.906-5.751a1.426 1.426 0 0 0-.013-.315.337.337 0 0 0-.114-.217.526.526 0 0 0-.31-.093c-.3.005-.763.166-2.984 1.09z"/>
            </svg>
          </a>
          <a href="https://www.instagram.com/" class="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-instagram" viewBox="0 0 16 16">
                  <path d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z"/>
                </svg>
          </a>
          <a href="https://gmail.com/" class="btn btn-primary">
              <svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" fill="currentColor" class="bi bi-google" viewBox="0 0 16 16">
                  <path d="M15.545 6.558a9.42 9.42 0 0 1 .139 1.626c0 2.434-.87 4.492-2.384 5.885h.002C11.978 15.292 10.158 16 8 16A8 8 0 1 1 8 0a7.689 7.689 0 0 1 5.352 2.082l-2.284 2.284A4.347 4.347 0 0 0 8 3.166c-2.087 0-3.86 1.408-4.492 3.304a4.792 4.792 0 0 0 0 3.063h.003c.635 1.893 2.405 3.301 4.492 3.301 1.078 0 2.004-.276 2.722-.764h-.003a3.702 3.702 0 0 0 1.599-2.431H8v-3.08h7.545z"/>
                </svg>
          </a>
         
        </div>
      </section>  
      <section class="">
        <div class="container text-center text-md-start mt-5">
          <div class="row mt-3">
            <div class="col-md-3 col-lg-4 col-xl-3 mx-auto mb-4">
              <h6 class="text-uppercase fw-bold mb-4">
                <i class="fas fa-gem me-3"></i>
                <img src="Новая папка/logo.jpg" width="300" height="300">
            </div>
            <div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
              <h6 class="text-uppercase fw-bold mb-4">
                Contact
              </h6>
              <p><i class="fas fa-home me-3"></i>Алматы, Жандосова 55</p>
              <p>
                <i class="fas fa-envelope me-3"></i>
                Narxoz University
              </p>
              <p><i class="fas fa-phone me-3"></i> + 7 777 695 11 21</p>
              <p><i class="fas fa-print me-3"></i> + 7 778 375 61 14</p>
            </div>
  
          </div>  
        </div>
      </section>
      <div class="text-center p-4" style="background-color: rgba(0, 0, 0, 0.05);">
        © 2022 Azattyk.kz
      </div>
    </footer>
      
</body>
</html>