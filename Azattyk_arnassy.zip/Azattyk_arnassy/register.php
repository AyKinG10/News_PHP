<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" type="text/css" href="reg.css">
  <title>Register</title>
</head>
<form action="mySql.php">
  <div class="container">
    <h1>Регестрация</h1>
    <h3>Зарегестрируйся что бы проити на сайт Library.com</h3>
    <hr>
    <label for="email"><b>Email</b></label>
    <input name="email" type="text" placeholder="Enter Email" id="email" required>

    <label for="name"><b>name</b></label>
    <input name="name" type="text" placeholder="Enter Name" id="name" required>


    <label for="psw"><b>Password</b></label>
    <input name="password" type="password" placeholder="Enter password" id="psw" required>

    <label for="psw-repeat"><b>Repeat Password</b></label>
    <input name="secondpass" type="password" placeholder="repeat password"  id="psw-repeat" required>
    <hr>
    <button type="submit" class="registerbtn">Register</button>
  </div>

  <div class="container signin">
    <h4><a href="Loginpage.php">Already have an account? <br>Sign in</a>.</h4>
  </div>
</form>
<body>

</body>
</html>