function blinkIt() {
    if (!document.all) return;
    else {
      for(i=0;i<document.all.tags('blink').length;i++){
         s=document.all.tags('blink')[i];
         s.style.visibility=(s.style.visibility=='visible')?'hidden':'visible';
      }
    }
   }