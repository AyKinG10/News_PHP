<?php
$servername = "localhost";
$username="root";
$password="";
$dbname="azattyk_news";
$conn=mysqli_connect($servername,$username,$password,$dbname);

if(mysqli_connect_errno()){
  die("Connection failed: " . $conn->connect_error);
}

$name=$_POST['name'];
$email=$_POST['email'];
$passwords=$_POST['password'];
if(isset($_COOKIE["email"])){
    if($_COOKIE["email"]!=""){
      $email=$_COOKIE["email"];
    }
  }
if(isset($_COOKIE["name"])){
    if($_COOKIE["name"]!=""){
      $name=$_COOKIE["name"];
    }
}
if(isset($_COOKIE["password"])){
  if($_COOKIE["password"]!=""){
    $password=$_COOKIE["password"];
  }
}

$query="INSERT INTO user(name, email ,password) VALUES ('$name','$email','$password')"; 
 
      if(mysqli_query($conn,$query)===TRUE){
        // echo "Добавлен новый пользователь";
        header('location:Azattyyk_arnastt.php');
      }else{
        echo "Error: " . $query ."<br>" .$conn->error;
      }
?>
