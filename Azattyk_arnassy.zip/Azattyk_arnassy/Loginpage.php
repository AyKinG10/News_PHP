<!DOCTYPE html>
<html>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
<section class="vh-100">
  <div class="container-fluid">
    <div class="row">
      <div class="col-sm-6 text-black">

        <div class="px-5 ms-xl-4">
          <i class="fas fa-crow fa-2x me-3 pt-5 mt-xl-4" style="color: #709085;"></i>
          <h1>Қош келдіңіз</h1>
        </div>

        <div class="d-flex align-items-center h-custom-2 px-5 ms-xl-4 mt-5 pt-5 pt-xl-0 mt-xl-n5">

          <form action="mySql.php" method="post" style="width: 23rem;">


            <h3 class="fw-normal mb-3 pb-3" style="letter-spacing: 1px;">Тіркеліңіз</h3>

            <div class="form-outline mb-4">
              <input name="email" type="email" id="form2Example18" class="form-control form-control-lg" />
              <label class="form-label" for="form2Example18">Логин</label>
            </div>
            <div class="form-outline mb-4">
              <input name="password" type="password" id="form2Example28" class="form-control form-control-lg" />
              <label class="form-label" for="form2Example28">Пароль</label>
            </div>

            <div class="pt-1 mb-4">
              <button class="btn btn-info btn-lg btn-block" type="submit">Кіру</button>
            </div>

            <p class="small mb-5 pb-lg-2"><a class="text-muted" href="#!">Құпия-сөзді ұмыттыңба ?</a></p>
            <p>Әлі тіркелмедің бе? <a href="register.php" class="link-info">Регестрируйтесь сейчас</a></p>

          </form>

        </div>

      </div>
      <div class="col-sm-6 px-0 d-none d-sm-block">
        <img src="https://micedata.s3.eu-central-1.amazonaws.com/MiceProjectData/Images/2020/4/29/1_9351_4470bdc6-c12d-461e-beb2-84a646f99a35.jpg" class="w-100 vh-100" style="object-fit: cover; object-position: left;">
      </div>
    </div>
  </div>

</section>

</html>