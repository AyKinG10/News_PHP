<?php
function OpenConn(){
$servername = "localhost";
$username="root";
$password="";
$dbname="azattyk_news";
$conn=mysqli_connect($servername,$username,$password,$dbname);
if(mysqli_connect_errno()){
  die("Connection failed: " . $conn->connect_error);
  return null;
}else{
    return $conn;
}
}
function CloseConn($conn){
    mysqli_close($conn);
}
?>