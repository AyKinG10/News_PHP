<?php
$email = "";
$password = "";
if (isset($_POST["email"])) {
    if ($_POST["email"] != "") {
        $email = $_POST["email"];
    } else {
        $email = "default@gmail.com";
    }

} else {
    $email = "default@gmail.com";
}

if (isset($_POST["password"])) {
    if ($_POST["password"] != "") {
        $password = $_POST["password"];
    } else {
        $password = "Default password";
    }
} else {
    $password = "Default password";
}

echo $password . "<br> " . $email;
?>